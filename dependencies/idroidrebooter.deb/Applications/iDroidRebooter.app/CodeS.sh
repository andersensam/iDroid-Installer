#!/bin/bash

platform=/Developer/Platforms/iPhoneOS.platform
allocate=${platform}/Developer/usr/bin/codesign_allocateexport
export CODESIGN_ALLOCATE=${allocate}

codesign -fs "Apple iPhone OS Application Signing" iDroidRebooter
